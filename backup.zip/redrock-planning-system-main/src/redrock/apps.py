from django.apps import AppConfig

class RedrockConfig(AppConfig): # name of the page/app
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'redrock'
